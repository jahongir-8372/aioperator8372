import tkinter as tk
import speech_recognition as sr
import threading
import requests
from gtts import gTTS
import playsound
import os

# 🔑 API ma'lumotlaringizni shu yerga yozing
API_KEY = "JX96fDbrkjsEyjr-qSD_fQdKTjVJ89mkNyvNVbHU"
API_URL = "https://muxlisa.api.url"  # Haqiqiy URL ni yozing

# Ovoz → Matn
def voice_to_text():
    r = sr.Recognizer()
    with sr.Microphone() as source:
        status_label.config(text="Gapiring...")
        audio = r.listen(source)
    try:
        text = r.recognize_google(audio, language='uz-UZ')
        status_label.config(text="Aniqlandi!")
        return text
    except sr.UnknownValueError:
        status_label.config(text="Tushunilmadi.")
        return ""
    except sr.RequestError:
        status_label.config(text="Google xizmati ulanmagan.")
        return ""

# APIga yuborish
def ask_muxlisa(text):
    headers = {"Authorization": f"Bearer {API_KEY}", "Content-Type": "application/json"}
    data = {"message": text}
    try:
        response = requests.post(API_URL, headers=headers, json=data)
        response.raise_for_status()
        reply = response.json().get("response", "Javob olinmadi.")
        return reply
    except Exception as e:
        return f"API xatoligi: {e}"

# Matn → Ovoz
def text_to_voice(text):
    tts = gTTS(text=text, lang='uz')
    filename = "reply.mp3"
    tts.save(filename)
    playsound.playsound(filename)
    os.remove(filename)

# Mikrofon tugmasi bosilganda
def on_mic_click():
    def task():
        user_text = voice_to_text()
        if user_text:
            conversation_text.insert(tk.END, f"Siz: {user_text}\n")
            conversation_text.see(tk.END)
            reply = ask_muxlisa(user_text)
            conversation_text.insert(tk.END, f"Muxlisa: {reply}\n\n")
            conversation_text.see(tk.END)
            text_to_voice(reply)
    threading.Thread(target=task).start()

# Tkinter oynasi
root = tk.Tk()
root.title("Muxlisa AI Assist")
root.geometry("600x400")

status_label = tk.Label(root, text="Tayyor", font=("Arial", 12))
status_label.pack(pady=5)

conversation_text = tk.Text(root, wrap=tk.WORD, height=15, width=70)
conversation_text.pack(pady=10)

mic_button = tk.Button(root, text="🎤 Gapirish", command=on_mic_click, font=("Arial", 12))
mic_button.pack(pady=10)

root.mainloop()
