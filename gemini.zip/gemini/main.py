import tkinter as tk
import openai

# OpenAI API kalitini yozing
openai.api_key = "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"

# Qisqa, tabiiy prompt
system_prompt = (
    "Sening isming Azizjon. Siz tez yordam operatorisiz. Xotirjam va tushunarli gapiring. "
    "Avval salom bering, favqulodda holatmi so‘rang, manzilini bilib oling. "
    "Nima bo‘lganini so‘rab, jiddiy bo‘lsa birinchi yordam ayting, "
    "yengil bo‘lsa maslahat bering. Boshqa mavzudagi savollarga javob bermang. "
    "Agar suhbat oxirida 'Rahmat' yoki 'tez yordam' so‘zlari bo‘lsa, sen ham rahmat aytib, qo'ng‘iroqni tugatishingiz mumkin. "
)

# Suhbat tarixini saqlash
chat_history = [{"role": "system", "content": system_prompt}]
conversation_log = []

def get_response():
    user_input = entry.get("1.0", "end-1c").strip()
    entry.delete("1.0", tk.END)

    if user_input:
        chat_history.append({"role": "user", "content": user_input})
        conversation_log.append(f"You: {user_input}")

        try:
            response = openai.ChatCompletion.create(
                model="gpt-4",
                messages=chat_history
            )
            reply = response['choices'][0]['message']['content']
            chat_history.append({"role": "assistant", "content": reply})
            conversation_log.append(f"Operator: {reply}")

            answer_text.set(reply)

            # Suhbat oxirida faylga yozish
            if "Rahmat" in reply or "tez yordam" in reply:
                with open("conversation.txt", "w", encoding="utf-8") as f:
                    f.write("\n".join(conversation_log))
        except Exception as e:
            answer_text.set(f"Xatolik yuz berdi: {str(e)}")

# Tkinter oynasi
root = tk.Tk()
root.title("Tez Yordam Operatori")
root.geometry("600x400")

# Kirish qutisi
entry = tk.Text(root, width=70, height=4)
entry.pack(pady=20)

# Javob ko‘rsatish uchun Label
answer_text = tk.StringVar()
answer_label = tk.Label(root, textvariable=answer_text, wraplength=500, justify="left")
answer_label.pack(pady=10)

# Tugma
ask_button = tk.Button(root, text="Javob yuborish", command=get_response)
ask_button.pack(pady=5)

# Oynani ishga tushirish
root.mainloop()
